import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.21.0";
import puppeteer from "https://deno.land/x/puppeteer@16.2.0/mod.ts";
import { corsHeaders } from "../_shared/cors.ts";
import { getReportTemplate } from "./templates.ts";

interface PDFGenerationRequest {
  reportId: string;
  templateId?: string;
  templateContent?: string; // Optional HTML content for the template
  options?: {
    format?: string;
    landscape?: boolean;
    printBackground?: boolean;
    preferCssPageSize?: boolean;
    margin?: {
      top?: string;
      right?: string;
      bottom?: string;
      left?: string;
    };
    headerTemplate?: string;
    footerTemplate?: string;
    displayHeaderFooter?: boolean;
  };
}

serve(async (req) => {
  // Handle CORS
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { reportId, templateId, templateContent, options = {} } = await req.json() as PDFGenerationRequest;
    
    if (!reportId) {
      throw new Error("Report ID is required");
    }

    // Create a Supabase client with the Auth context of the function
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        auth: { persistSession: false }
      }
    );
    
    // Fetch report data
    const { data: reportData, error: reportError } = await supabaseClient
      .from("astrology_reports")
      .select(`
        *,
        birth_charts!inner(
          name, 
          birth_date, 
          birth_time, 
          birth_location, 
          chart_data
        ),
        user_profiles!inner(
          display_name,
          avatar_url,
          subscription_tier
        )
      `)
      .eq("id", reportId)
      .single();
    
    if (reportError) {
      throw new Error(`Error fetching report: ${reportError.message}`);
    }
    
    if (!reportData) {
      throw new Error("Report not found");
    }
    
    console.log("Fetched report data:", JSON.stringify({
      id: reportData.id,
      title: reportData.title,
      report_type: reportData.report_type
    }));

    // Determine which template to use
    let template;
    
    // First priority: Use provided template content directly if available
    if (templateContent) {
      template = templateContent;
      console.log("Using provided template content");
    } 
    // Second priority: Look up template by ID in the database
    else if (templateId) {
      const { data: templateData, error: templateError } = await supabaseClient
        .from("report_templates")
        .select("html_content")
        .eq("id", templateId)
        .single();
        
      if (templateError) {
        console.warn("Error fetching template:", templateError.message);
      } else if (templateData?.html_content) {
        template = templateData.html_content;
        console.log("Using database template with ID:", templateId);
      }
    }

    // Third priority: Fetch the default template for this report type from database
    if (!template) {
      const { data: defaultTemplate } = await supabaseClient
        .from("report_templates")
        .select("html_content")
        .eq("report_type", reportData.report_type)
        .eq("is_default", true)
        .single();
        
      if (defaultTemplate?.html_content) {
        template = defaultTemplate.html_content;
        console.log("Using default template from database for report type:", reportData.report_type);
      }
    }
    
    // Last resort: Use built-in templates if nothing found in the database
    if (!template) {
      template = getReportTemplate(reportData.report_type);
      console.log("Using built-in template for report type:", reportData.report_type);
    }
    
    // Process the report data through the template
    const htmlContent = processTemplate(template, reportData);
    
    // Generate PDF using Puppeteer
    console.log("Starting Puppeteer for PDF generation...");
    const browser = await puppeteer.launch({ 
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--font-render-hinting=none"] 
    });
    
    const page = await browser.newPage();
    
    // Set viewport to ensure content renders properly
    await page.setViewport({
      width: 1280,
      height: 1024,
      deviceScaleFactor: 1,
    });
    
    // Add default styling to ensure content is visible
    const htmlWithStyles = `
      <html>
      <head>
        <style>
          body {
            font-family: Arial, sans-serif;
            font-size: 12pt;
            color: #000;
            background-color: #fff;
            margin: 0;
            padding: 0;
          }
          .report-section {
            margin-bottom: 20px;
          }
          .section-title {
            font-size: 16pt;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
          }
          .section-content p {
            margin-bottom: 10px;
          }
        </style>
      </head>
      <body>
        ${htmlContent}
      </body>
      </html>
    `;
    
    // Set content with proper timeout and wait
    await page.setContent(htmlWithStyles, { 
      waitUntil: ["load", "networkidle0"],
      timeout: 30000 
    });
    
    // Wait for any images or content to fully render
    await page.evaluate(() => new Promise(resolve => setTimeout(resolve, 1000)));
    
    // Set default PDF options with careful attention to browser compatibility
    const pdfOptions = {
      format: "A4",
      printBackground: true,
      preferCSSPageSize: true,
      scale: 0.98, // Slightly reduce scale to avoid content cutoff
      margin: {
        top: "25mm",
        right: "20mm",
        bottom: "25mm",
        left: "20mm"
      },
      displayHeaderFooter: true,
      headerTemplate: `
        <div style="font-size: 10px; width: 100%; text-align: center; padding: 10px 0; font-family: Arial, sans-serif;">
          <span>Mystic Banana Astrology</span>
        </div>
      `,
      footerTemplate: `
        <div style="font-size: 10px; width: 100%; text-align: center; padding: 10px 0; font-family: Arial, sans-serif;">
          <span>Page </span>
          <span class="pageNumber"></span>
          <span> of </span>
          <span class="totalPages"></span>
          <div style="margin-top: 5px;">© ${new Date().getFullYear()} Mystic Banana Astro</div>
        </div>
      `,
      timeout: 60000, // Increase timeout for PDF generation
      ...options
    };
    
    console.log("Generating PDF with options:", JSON.stringify(pdfOptions));
    const pdfBuffer = await page.pdf(pdfOptions);
    await browser.close();
    
    // Create a unique filename
    const timestamp = new Date().getTime();
    const filename = `report-${reportId}-${timestamp}.pdf`;
    const filePath = `reports/${filename}`;
    
    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabaseClient
      .storage
      .from("report-pdfs")
      .upload(filePath, pdfBuffer, {
        contentType: "application/pdf",
        cacheControl: "3600"
      });
      
    if (uploadError) {
      throw new Error(`Error uploading PDF: ${uploadError.message}`);
    }
    
    // Get a signed URL for the uploaded file
    const { data: urlData } = await supabaseClient
      .storage
      .from("report-pdfs")
      .createSignedUrl(filePath, 60 * 60 * 24); // 24 hour expiry
      
    // Save the PDF reference in the database
    await supabaseClient
      .from("report_pdfs")
      .insert({
        report_id: reportId,
        template_id: templateId, // Store which template was used
        file_path: filePath,
        created_at: new Date().toISOString()
      });
      
    return new Response(
      JSON.stringify({
        success: true,
        message: "PDF report generated successfully",
        downloadUrl: urlData?.signedUrl,
        pdfPath: filePath
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200
      }
    );
    
  } catch (error) {
    console.error("PDF Generation Error:", error);
    return new Response(
      JSON.stringify({
        error: error.message || "Failed to generate PDF report",
        success: false
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500
      }
    );
  }
});

// Process the template with report data
function processTemplate(template: string, reportData: any): string {
  let processedTemplate = template;
  
  // Replace basic placeholders
  const placeholders = {
    "{{REPORT_TITLE}}": reportData.title || "Astrological Report",
    "{{PERSON_NAME}}": reportData.birth_charts?.name || "Unknown",
    "{{BIRTH_DATE}}": reportData.birth_charts?.birth_date ? formatDate(reportData.birth_charts.birth_date) : "Unknown",
    "{{BIRTH_TIME}}": reportData.birth_charts?.birth_time || "Unknown",
    "{{BIRTH_LOCATION}}": reportData.birth_charts?.birth_location ? 
      `${reportData.birth_charts.birth_location.city}, ${reportData.birth_charts.birth_location.country}` : "Unknown",
    "{{REPORT_TYPE}}": formatReportType(reportData.report_type),
    "{{GENERATION_DATE}}": formatDate(new Date().toISOString()),
    "{{REPORT_CONTENT}}": processReportContent(reportData.content)
  };
  
  // Replace each placeholder
  for (const [placeholder, value] of Object.entries(placeholders)) {
    processedTemplate = processedTemplate.replace(new RegExp(placeholder, "g"), value);
  }
  
  // Process special sections if available
  if (reportData.birth_charts?.chart_data) {
    processedTemplate = processChartData(processedTemplate, reportData.birth_charts.chart_data);
  }
  
  return processedTemplate;
}

// Format the report content into structured HTML
function processReportContent(content: string): string {
  if (!content) return "";
  
  // Split by markdown headers
  const sections = content.split(/\*\*([^*]+)\*\*/);
  let processedContent = "";
  
  for (let i = 1; i < sections.length; i += 2) {
    const title = sections[i];
    const body = sections[i + 1] || "";
    
    // Create a section with title and formatted body
    processedContent += `
      <div class="report-section">
        <h2 class="section-title">${title}</h2>
        <div class="section-content">
          ${formatTextContent(body)}
        </div>
      </div>
    `;
  }
  
  return processedContent;
}

// Format plain text into HTML paragraphs
function formatTextContent(text: string): string {
  if (!text) return "";
  return text
    .split(/\n\n+/)
    .map(paragraph => `<p>${paragraph.replace(/\n/g, "<br>")}</p>`)
    .join("");
}

// Process chart data into visual elements
function processChartData(template: string, chartData: any): string {
  // This would be expanded to generate chart visualizations
  // For now, just return the template
  return template;
}

// Format report type for display
function formatReportType(type: string): string {
  if (!type) return "Astrological";
  
  return type
    .split("-")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

// Format date for display
function formatDate(dateString: string): string {
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  } catch (e) {
    return dateString;
  }
}
